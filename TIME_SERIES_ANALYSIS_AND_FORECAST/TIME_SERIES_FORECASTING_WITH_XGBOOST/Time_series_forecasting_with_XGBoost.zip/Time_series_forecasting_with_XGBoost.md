# TIME SERIES WITH XGBOOST - ADVANCED METHODS

Ref. https://www.youtube.com/watch?v=z3ZnOW-S550
<br>This Document Created by: Hernan Chavez<br/>
Date: 2/29/2024

# USING MACHINE LEARNING TO FORECAST ENERGY CONSUMPTION


```python
#pip install xgboost
```


```python
#pip install scikit-learn
```


```python
#pip install sklearn
```


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

import xgboost as xgb
from sklearn.metrics import mean_squared_error # WE ARE GOING TO USE ROOT MEAN SQUARED ERROR

color_pal = sns.color_palette()
plt.style.use('fivethirtyeight')
```


```python
# READ THE DATA SET

df = pd.read_csv('PJME_hourly.csv')
df = df.set_index('Datetime')
df.index = pd.to_datetime(df.index)
df.head() # THE INDEX IS THE DATETIME COLUMN AND THE COLUMN IS THE MEGAWATTS WE ARE TRYING TO PREDICT
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PJME_MW</th>
    </tr>
    <tr>
      <th>Datetime</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2002-12-31 01:00:00</th>
      <td>26498.0</td>
    </tr>
    <tr>
      <th>2002-12-31 02:00:00</th>
      <td>25147.0</td>
    </tr>
    <tr>
      <th>2002-12-31 03:00:00</th>
      <td>24574.0</td>
    </tr>
    <tr>
      <th>2002-12-31 04:00:00</th>
      <td>24393.0</td>
    </tr>
    <tr>
      <th>2002-12-31 05:00:00</th>
      <td>24860.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# WE WANT TO VISUALIZE THIS DATA
df.plot(style='.', figsize=(15,5), color=color_pal[0], title='PJME Energy Use in MW')
plt.xticks(rotation=90)
plt.show()
```


    
![png](output_7_0.png)
    



```python
# WE CAN IDENTIFY SOME REALLY LOW VALUES THAT COULD POTENTIALLY REPRESENT OUTLIERs...MAYBE A BLACKOUT.
# WE MUST BE VERY CAREFUL ABOUT NOT REMOVING THINGS THAT MIGHT EXPLAIN DATA BEHAVIOR, AND THAT WE WOULD LIKE THE MODEL TO LEARN FROM.

df['PJME_MW'].plot(kind='hist', bins=500)
```




    <Axes: ylabel='Frequency'>




    
![png](output_8_1.png)
    



```python
# WE CAN SEE THAT MOST OF THE TIME VALUES ARE BETWEEN 20,000 AND ABOVE 50,000
# WE WANT TO LOOK AT WHEN VALUES ARE LOWER THAN THIS TO SEE IF THERE ARE ANY EXTREME OUTLIERS 
# THAT WE MIGHT WANT TO REMOVE.

df_outl = df.query('PJME_MW < 20000').plot(figsize=(15,5), style='.')
plt.xticks(rotation=90)
plt.show()
```


    
![png](output_9_0.png)
    



```python
# WE CAN SEE VALUES UNDER 20,000, 
# THERE IS THAT AREA WHERE WE SEE SOME OUTLIERS THAT DON'T LOOK LIKE THEY ARE LEGITIMATE
```


```python
# WE CAN MAKE THIS MORE OBVIOUS BY LOWERING THE THRESHOLD

df_outl = df.query('PJME_MW < 19000').plot(figsize=(15,5), style='.')
plt.xticks(rotation=90)
plt.show()
```


    
![png](output_11_0.png)
    



```python
# WE COULD USE THINGS LIKE STANDARD DEVIATIONS AND NUMBER OF OUTLIERS, BUT FOR NOW...
# WE WILL SETTLE WITH A VISUAL INSPECTION TO REMOVE OUR OUTLIERS.

df = df.query('PJME_MW >= 19000').copy()

df.plot(style='.', figsize=(15,5), color=color_pal[0], title='PJME Energy Use in MW')
plt.xticks(rotation=90)
plt.show()
```


    
![png](output_12_0.png)
    



```python
# NOW WE WILL DO A TRAIN/TEST SPLIT USING 'TIME SERIES CROSS VALIDATION'
# THERE IS A TOOL THAT ALLOWS US TO FIND THE MAX TRAINING SIZE (NUMBER OF SPLITS) 
# AND CREATE THOSE SPLITS FOR US.

from sklearn.model_selection import TimeSeriesSplit

tss = TimeSeriesSplit(n_splits=5, test_size=24*365*1, gap=24) #...ASSUMING WE WANT TO PREDICT 1 YEAR
df = df.sort_index() # IF THIS IS NOT SORTED... THEN TIME SPLIT WILL NOT WORK

# WE CAN ALSO DEFINE A GAP BETWEEN THE TRAINING AND THE VALIDATION SET WE ARE SPLITTING ON EACH TIME
# WE SET THAT TO 24 HOURS BETWEEN THE TRAINING SET AND THE TEST

# NOW WE LOOP OVER THE GENERATOR AND APPLYING IT OVER THE DATA SET
for train_idx, val_idx in tss.split(df):
    break

train_idx # THE INDICES IN THE DATAFRAME THAT WILL BE OUR TRAINING SET
```




    array([     0,      1,      2, ..., 101524, 101525, 101526])




```python
val_idx # THE VALIDATION INDICES
```




    array([101551, 101552, 101553, ..., 110308, 110309, 110310])




```python
# LET'S VISUALIZE THIS...

fig, axs = plt.subplots(5, 1, figsize = (15, 15), sharex = True)

fold = 0 # WE ARE GOING TO TRACT THE FOLDS
for train_idx, val_idx in tss.split(df):
    train = df.iloc[train_idx]
    test = df.iloc[val_idx]
    train['PJME_MW'].plot(ax=axs[fold], label='Training Set', title=f'Data Train/Test Split Fold {fold}')
    test['PJME_MW'].plot(ax=axs[fold], label='Test Set')
    axs[fold].axvline(test.index.min(), color='black', ls='--')
    fold += 1
plt.show()
```


    
![png](output_15_0.png)
    



```python
# WE CAN SEE HOW EACH FOLD WORKS...
# WE HAVE ONE YEAR OF VALIDATION SET ON EACH FOLD
# WE ARE TESTING EACH OF THESE FIVE YEARS (RED AREAS IN GRAPHS) INDEPENDENTLY. 
# IT IS IMPORTANT TO DO IT THIS WAY...
# FOR EXAMPLE WE WOULD NOT WANT TO TAKE OUT ONE YEAR AND TRAIN ON DATA AFTER IT
# THAT WOULD BE A LEAK ABOUT OUR TARGET INTO THIS VALIDATION.
# AND WHEN WE ARE RUNNING THIS WE ARE GOING TO BE DOING OUR CROSS VALIDATION WE WANT TO BE LEAK-FREE AS POSSIBLE
```


```python
# NOW LETS TALK ABOUT FORECASTING HORIZON (HOW FAR INTO THE FUTURE WE WANT TO PREDICT)

# GENERALLY THE FURTHER OUT INTO THE FUTURE, THE HARDER TO PREDICT

# ALSO, YOU CAN'T ADD LAG FEATURE BACK FURTHER THAN YOUR TIME HORIZON

# BUT FIRST LET'S ADD THE TIME SERIES FEATURES TO OUT DATA

def create_features(df):
    df = df.copy()
    df['hour'] = df.index.hour
    df['dayofweek'] = df.index.dayofweek
    df['quarter'] = df.index.quarter
    df['month'] = df.index.month
    df['year'] = df.index.year
    df['dayofyear'] = df.index.dayofyear
    df['dayofmonth'] = df.index.day
    df['weekofyear'] = df.index.isocalendar().week
    return df

df = create_features(df)
```


```python
# THE WAY LAG FEATURES WORK IS: WE ARE ESSENTIALLY TELLING THE MODEL TO LOOK INTO THE PAST HOWEVER MANY DAYS AND 
# TO USE THE TARGET VALUE FOR THAT MANY DAYS IN THE PAST AS A NEW FEATURE THAT YOU FEED INTO THE MODEL. 

def add_lags(df):
    target_map = df['PJME_MW'].to_dict() # WHY 364 AND NOT 365, BECAUSE 364 IS DIVIDIBLE BY 7, 
    # SO WE ARE TAKING THE SAME DAY OF THE WEEK ONE YEAR INTO THE PAST

    # REMEBER THAT THE LAG CAN'T BE LONGER THAN YOUR FORECASTING HORIZON

    df['lag1'] = (df.index - pd.Timedelta('364 days')).map(target_map) # FOR 1 YEAR
    df['lag2'] = (df.index - pd.Timedelta('728 days')).map(target_map) # FOR 2 YEARS
    df['lag3'] = (df.index - pd.Timedelta('1092 days')).map(target_map) # FOR 3 YEARS
    return df

df = add_lags(df)
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PJME_MW</th>
      <th>hour</th>
      <th>dayofweek</th>
      <th>quarter</th>
      <th>month</th>
      <th>year</th>
      <th>dayofyear</th>
      <th>dayofmonth</th>
      <th>weekofyear</th>
      <th>lag1</th>
      <th>lag2</th>
      <th>lag3</th>
    </tr>
    <tr>
      <th>Datetime</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2002-01-01 01:00:00</th>
      <td>30393.0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>2002</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2002-01-01 02:00:00</th>
      <td>29265.0</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>2002</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2002-01-01 03:00:00</th>
      <td>28357.0</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>2002</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2002-01-01 04:00:00</th>
      <td>27899.0</td>
      <td>4</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>2002</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2002-01-01 05:00:00</th>
      <td>28057.0</td>
      <td>5</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>2002</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PJME_MW</th>
      <th>hour</th>
      <th>dayofweek</th>
      <th>quarter</th>
      <th>month</th>
      <th>year</th>
      <th>dayofyear</th>
      <th>dayofmonth</th>
      <th>weekofyear</th>
      <th>lag1</th>
      <th>lag2</th>
      <th>lag3</th>
    </tr>
    <tr>
      <th>Datetime</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2018-08-02 20:00:00</th>
      <td>44057.0</td>
      <td>20</td>
      <td>3</td>
      <td>3</td>
      <td>8</td>
      <td>2018</td>
      <td>214</td>
      <td>2</td>
      <td>31</td>
      <td>42256.0</td>
      <td>41485.0</td>
      <td>38804.0</td>
    </tr>
    <tr>
      <th>2018-08-02 21:00:00</th>
      <td>43256.0</td>
      <td>21</td>
      <td>3</td>
      <td>3</td>
      <td>8</td>
      <td>2018</td>
      <td>214</td>
      <td>2</td>
      <td>31</td>
      <td>41210.0</td>
      <td>40249.0</td>
      <td>38748.0</td>
    </tr>
    <tr>
      <th>2018-08-02 22:00:00</th>
      <td>41552.0</td>
      <td>22</td>
      <td>3</td>
      <td>3</td>
      <td>8</td>
      <td>2018</td>
      <td>214</td>
      <td>2</td>
      <td>31</td>
      <td>39525.0</td>
      <td>38698.0</td>
      <td>37330.0</td>
    </tr>
    <tr>
      <th>2018-08-02 23:00:00</th>
      <td>38500.0</td>
      <td>23</td>
      <td>3</td>
      <td>3</td>
      <td>8</td>
      <td>2018</td>
      <td>214</td>
      <td>2</td>
      <td>31</td>
      <td>36490.0</td>
      <td>35406.0</td>
      <td>34552.0</td>
    </tr>
    <tr>
      <th>2018-08-03 00:00:00</th>
      <td>35486.0</td>
      <td>0</td>
      <td>4</td>
      <td>3</td>
      <td>8</td>
      <td>2018</td>
      <td>215</td>
      <td>3</td>
      <td>31</td>
      <td>33539.0</td>
      <td>32094.0</td>
      <td>31695.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# NOW WE ARE GOING TO PUT IT ALTOGETHER...

# WE HAVE OUR NEW LAG FEATURES,...

# WE HAVE OUR CORSS VALIDATION SETUP, AND...

# WE ARE GOING TO LOOP OVER THESE CROSS VALIDATIONS FOLDS AND TRAIN OUR MODEL,...

# WE ARE GOING TO TRAIN ON THE TRAINING AND TEST SET FROM THIS TRAIN TEST SPLIT FIVE DIFFERENT TIMES, AND...

# WE ARE GOING TO SCORE OUR MODEL USING THE MEAN SQUARE ERROR, AND...

# WE ARE GOING TO SAVE THOSE SCORES TO A LIST SO THAT WE CAN EVALUATE OUR SCORE ACROSS ALL DIFFERENT FOLDS...

# SO LET'S GO AHEAD AND RUN THIS TRAINING LOOP SO WE CAN SEE IT

fold = 0
preds = []
scores = []

for train_idx, val_idx in tss.split(df):
    train = df.iloc[train_idx]
    test = df.iloc[val_idx]
    
    train = create_features(train)
    test = create_features(test)
    
    FEATURES = ['dayofyear', 'hour', 'dayofweek', 'quarter', 'month', 'year', 'lag1', 'lag2', 'lag3']
    TARGET = 'PJME_MW'
    
    x_train = train[FEATURES]
    y_train = train[TARGET]
    
    x_test = test[FEATURES]
    y_test = test[TARGET]
    
    reg = xgb.XGBRegressor(base_score=0.5, booster='gbtree', n_estimators=1000, early_stopping_rounds=50,
                          objective='reg:linear', max_depth=3, learning_rate=0.01)
    
    reg.fit(x_train, y_train, eval_set=[(x_train, y_train), (x_test, y_test)], verbose=100)
    
    y_pred = reg.predict(x_test)
    preds.append(y_pred)
    score = np.sqrt(mean_squared_error(y_test, y_pred))
    scores.append(score)
```

    [0]	validation_0-rmse:32732.49608	validation_1-rmse:31956.60163


    /Users/c105624/Documents/anaconda3/lib/python3.11/site-packages/xgboost/core.py:160: UserWarning: [01:48:21] WARNING: /Users/runner/work/xgboost/xgboost/src/objective/regression_obj.cu:209: reg:linear is now deprecated in favor of reg:squarederror.
      warnings.warn(smsg, UserWarning)


    [100]	validation_0-rmse:12532.64369	validation_1-rmse:11906.14134
    [200]	validation_0-rmse:5747.92495	validation_1-rmse:5359.26490
    [300]	validation_0-rmse:3872.48134	validation_1-rmse:3900.86965
    [400]	validation_0-rmse:3434.23853	validation_1-rmse:3762.33705
    [441]	validation_0-rmse:3370.76149	validation_1-rmse:3764.48078
    [0]	validation_0-rmse:32672.16678	validation_1-rmse:32138.89241


    /Users/c105624/Documents/anaconda3/lib/python3.11/site-packages/xgboost/core.py:160: UserWarning: [01:48:23] WARNING: /Users/runner/work/xgboost/xgboost/src/objective/regression_obj.cu:209: reg:linear is now deprecated in favor of reg:squarederror.
      warnings.warn(smsg, UserWarning)


    [100]	validation_0-rmse:12513.65574	validation_1-rmse:12224.93373
    [200]	validation_0-rmse:5753.34937	validation_1-rmse:5662.07107
    [300]	validation_0-rmse:3902.71304	validation_1-rmse:3933.73076
    [400]	validation_0-rmse:3476.90515	validation_1-rmse:3590.55005
    [500]	validation_0-rmse:3353.72424	validation_1-rmse:3516.39915
    [600]	validation_0-rmse:3297.94766	validation_1-rmse:3481.94003
    [700]	validation_0-rmse:3258.48267	validation_1-rmse:3461.37383
    [800]	validation_0-rmse:3221.51553	validation_1-rmse:3436.49603
    [900]	validation_0-rmse:3190.11480	validation_1-rmse:3428.88699
    [999]	validation_0-rmse:3166.16314	validation_1-rmse:3420.31309
    [0]	validation_0-rmse:32631.20370	validation_1-rmse:31073.29733


    /Users/c105624/Documents/anaconda3/lib/python3.11/site-packages/xgboost/core.py:160: UserWarning: [01:48:29] WARNING: /Users/runner/work/xgboost/xgboost/src/objective/regression_obj.cu:209: reg:linear is now deprecated in favor of reg:squarederror.
      warnings.warn(smsg, UserWarning)


    [100]	validation_0-rmse:12499.28425	validation_1-rmse:11136.70202
    [200]	validation_0-rmse:5750.81453	validation_1-rmse:4813.22087
    [300]	validation_0-rmse:3917.04200	validation_1-rmse:3553.46419
    [400]	validation_0-rmse:3494.55924	validation_1-rmse:3495.32356
    [411]	validation_0-rmse:3475.26636	validation_1-rmse:3503.65414
    [0]	validation_0-rmse:32528.44438	validation_1-rmse:31475.39670


    /Users/c105624/Documents/anaconda3/lib/python3.11/site-packages/xgboost/core.py:160: UserWarning: [01:48:31] WARNING: /Users/runner/work/xgboost/xgboost/src/objective/regression_obj.cu:209: reg:linear is now deprecated in favor of reg:squarederror.
      warnings.warn(smsg, UserWarning)


    [100]	validation_0-rmse:12462.36581	validation_1-rmse:12020.28283
    [200]	validation_0-rmse:5738.57925	validation_1-rmse:5796.45874
    [300]	validation_0-rmse:3918.53218	validation_1-rmse:4388.39477
    [400]	validation_0-rmse:3501.24270	validation_1-rmse:4173.36380
    [500]	validation_0-rmse:3384.02490	validation_1-rmse:4119.56538
    [600]	validation_0-rmse:3325.50024	validation_1-rmse:4105.01446
    [700]	validation_0-rmse:3282.73755	validation_1-rmse:4091.23557
    [800]	validation_0-rmse:3250.37610	validation_1-rmse:4083.12690
    [900]	validation_0-rmse:3223.87814	validation_1-rmse:4081.46154
    [999]	validation_0-rmse:3199.82843	validation_1-rmse:4052.57120
    [0]	validation_0-rmse:32462.05557	validation_1-rmse:31463.90500


    /Users/c105624/Documents/anaconda3/lib/python3.11/site-packages/xgboost/core.py:160: UserWarning: [01:48:37] WARNING: /Users/runner/work/xgboost/xgboost/src/objective/regression_obj.cu:209: reg:linear is now deprecated in favor of reg:squarederror.
      warnings.warn(smsg, UserWarning)


    [100]	validation_0-rmse:12445.87740	validation_1-rmse:11963.42706
    [200]	validation_0-rmse:5752.44568	validation_1-rmse:5611.92884
    [300]	validation_0-rmse:3951.51709	validation_1-rmse:4156.41403
    [400]	validation_0-rmse:3539.25569	validation_1-rmse:4006.58873
    [439]	validation_0-rmse:3480.87364	validation_1-rmse:4011.68406



```python
# SO ITS DONE TRAINING 5 FOLDS...

# WE HAVE RAN FIVE DIFFERENT EXPERIMENTS AND WE CAN SEE HOW THE SCORES ARE FOR EACH ONE OF THE FIVE, AND...

# IDEALLY THE MORE WE START HYPERPARAMETER TUNNING AND THE MORE FEATURES WE ADD, 

# WE WANT TO SEE THE SCORE GET BETTER ACROSS ALL OF THESE FOLDS,... 

# SO THERE ARE A FEW DIFFERENT WAYS OF JUST EVALUATING THIS

# THESE WOULD BE THE VALIDATION SCORES WE WOULD LIKE TO APPROVE UPON

print(f'Score across folds {np.mean(scores):0.4f}')
print(f'Fold scores: {scores}')
```

    Score across folds 3742.5833
    Fold scores: [3760.8277187583353, 3420.313091887879, 3478.018038580526, 4052.5712055405547, 4001.186553933809]



```python
# NOW WE'LL SHOW HOW TO PREDICT INTO THE FUTURE...

# BUT BEFORE, WE WANT TO TRAIN THE MODEL ONE MORE TIME WITH ALL THE TRAINING DATA...

# THIS IS IMPORTANT BECAUSE AFTER WE HAVE DONE THIS TRAIN VALIDATION FOR TIME SERIES
# WE STILL WANT TO LEVERAGE ALL THE DATA WE HAVE FOR OUR MODEL, THAT WE WILL BE USING TO
# FORECAST INTO THE FUTURE. 

# SO INSTEAD OF BEFORE WHERE WE CREATED THE X AND Y VALUE FROM THE TRAIN AND VALIDATION SEPARATELY,... 
# THIS TIME WE ARE GOING TO CREATE THE FEATURES ON ALL OF OUR DATA.

# WE HAVE ALSO CHANGED THE NUMBER OF ESTIMATORS THAT WE WILL TRAIN TO 500. 
# THE REASON FOR THAT IS BECAUSE WE CAN SEE ON THE RUNS FROM THE FOLDS 
# WHEN WE DID CROSS VALIDATION THAT AROUND THE 500th ITERATION
# IS WHEN THE MODELS START TO OVERFIT 
# SO YOU COULD ACTUALLY TAKE THE AVERAGE VALUE ACROSS FOLDS WHEN IT START TO OVERFIT...
# THIS WILL BE GOOD JUST FOR TRAINING HERE...
# AFTER 500 ITERATIONS THERE IS CHANCE THAT IT MIGHT BE OVERFITTING A LITTLE BIT TOO MUCH...

# SO WE'LL RUN  THIS TRAINING AGAIN ONE LAST TIME SO WE HAVE OUR REGRESSOR THAT WE WILL CALL REG

# RETRAIN ON ALL DATA
df = create_features(df)

FEATURES = ['dayofyear', 'hour', 'dayofweek', 'quarter', 'month', 'year', 'lag1', 'lag2', 'lag3']
TARGET = 'PJME_MW'

x_all = df[FEATURES]
y_all = df[TARGET]

reg = xgb.XGBRegressor(base_score=0.5, booster='gbtree', n_estimators=500,
                          objective='reg:linear', max_depth=3, learning_rate=0.01)
    
reg.fit(x_all, y_all, eval_set=[(x_all, y_all)], verbose=100)
```

    [0]	validation_0-rmse:32403.88991


    /Users/c105624/Documents/anaconda3/lib/python3.11/site-packages/xgboost/core.py:160: UserWarning: [01:48:40] WARNING: /Users/runner/work/xgboost/xgboost/src/objective/regression_obj.cu:209: reg:linear is now deprecated in favor of reg:squarederror.
      warnings.warn(smsg, UserWarning)


    [100]	validation_0-rmse:12426.83220
    [200]	validation_0-rmse:5751.73275
    [300]	validation_0-rmse:3971.53256
    [400]	validation_0-rmse:3571.21833
    [499]	validation_0-rmse:3456.76877





<style>#sk-container-id-1 {color: black;}#sk-container-id-1 pre{padding: 0;}#sk-container-id-1 div.sk-toggleable {background-color: white;}#sk-container-id-1 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-1 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-1 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-1 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-1 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-1 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-1 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-1 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-1 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-1 div.sk-item {position: relative;z-index: 1;}#sk-container-id-1 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-1 div.sk-item::before, #sk-container-id-1 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-1 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-1 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-1 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-1 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-1 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-1 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-1 div.sk-label-container {text-align: center;}#sk-container-id-1 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-1 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>XGBRegressor(base_score=0.5, booster=&#x27;gbtree&#x27;, callbacks=None,
             colsample_bylevel=None, colsample_bynode=None,
             colsample_bytree=None, device=None, early_stopping_rounds=None,
             enable_categorical=False, eval_metric=None, feature_types=None,
             gamma=None, grow_policy=None, importance_type=None,
             interaction_constraints=None, learning_rate=0.01, max_bin=None,
             max_cat_threshold=None, max_cat_to_onehot=None,
             max_delta_step=None, max_depth=3, max_leaves=None,
             min_child_weight=None, missing=nan, monotone_constraints=None,
             multi_strategy=None, n_estimators=500, n_jobs=None,
             num_parallel_tree=None, objective=&#x27;reg:linear&#x27;, ...)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label sk-toggleable__label-arrow">XGBRegressor</label><div class="sk-toggleable__content"><pre>XGBRegressor(base_score=0.5, booster=&#x27;gbtree&#x27;, callbacks=None,
             colsample_bylevel=None, colsample_bynode=None,
             colsample_bytree=None, device=None, early_stopping_rounds=None,
             enable_categorical=False, eval_metric=None, feature_types=None,
             gamma=None, grow_policy=None, importance_type=None,
             interaction_constraints=None, learning_rate=0.01, max_bin=None,
             max_cat_threshold=None, max_cat_to_onehot=None,
             max_delta_step=None, max_depth=3, max_leaves=None,
             min_child_weight=None, missing=nan, monotone_constraints=None,
             multi_strategy=None, n_estimators=500, n_jobs=None,
             num_parallel_tree=None, objective=&#x27;reg:linear&#x27;, ...)</pre></div></div></div></div></div>




```python
# WE CAN CALL THE REGRESSOR REG AND PREDICT IN THE FUTURE...BUT FIRST WE NEED TO MAKE THIS FUTURE DATAFRAME
# AND WE CAN DO THAT PRETTY EASILY BY USING PANDA'S DATE RANGE FUNCTION...
# IF WE USE PD RANGE DATE WE CAN GIVE IT A START DATE AND END DATE AND...
# OTHER THINGS LIKE FREQUENCY, WHICH WILL BE IMPORTANT FOR US TO USE.

# IF WE LOOK AT OUR DATAFRAME  AND OUR INDEX MAX VALUE GOES UP TO 2018 SO WE'LL TAKE THIS DATE 
# AND ACTUALLY MAKE THIS THE FIRST DAY OF OUR FUTURE DATAFRAME THAT WE ARE GOING TO CREATE...
# JUST TO BE SAFE WE WILL JUST GO UP UNTIL THE FIRST DAY OF THAT MONTH AS OUR LAST DATE SO THIS IS 
# THE END DATE RANGE NOW...
# IF WE JUST RUN THIS YOU CAN TSEE THAT WE HAVE A LIST OF DATES FROM THE START TO THE END DATE

# BUT REMEMBER THAT WE WANT TO PREDICT HOURLY!!!!!
# SO WE ARE GOING TO ADD 'FREQ=1HOUR'
# NOW WE'LL HAVE HOURLY TIMESTAMPS BETWEEN THESE TWO DIFFERENT DATES
# NOW WE WANT TO CREATE A DATAFRAME OFF THIS AND WE WILL PASS THE INDEX AS THIS FUTURE DATES TIME STAMPS 
# WE CAN CALL THIS FUTURE_DF FOR FUTURE DATAFRAME

# BECAUSE WE HAVE LAG FEATURES WE WANT TO STICK THESE FEATURES DATAFRAME ONTO THE END OF OUR EXISTING DATA, SO
# WE CAN ADD THOSE LAG FEATURES CORRECTLY AND BEFORE WE DO THAT WE CREATE A COLUMN CALLED 'isFuture'...
# SO WE CAN EASILY IDENTIFY WHICH OF THE VALUES ARE FUTURE AND WHICH OF THE VALUES ARE NOT

# THEN WE WILL CREATE A NEW DATAFRAME WHICH IS JUST THE CONCATENATION OF OUR DATAFRAME WITH FUTURE AND 
# NOW IF WE LOOK AT DF_AND_FUTURE WE CAN SEE THAT IT GOES ALL THE WAY OUT TO THIS 2019 DATE.
# WE NEED TO REMEMBER TO CREATE OUR FEATURES ON TOP OF THIS AND ALSO CREATE OR ADD OUR LAG FEATURES
# AND THAT'S WHY IT'S NICE THAT WE CREATED THOSE FUNCTIONS. 

# NOW THAT WE HAVE ADDED OUR LAGS, WE CAN NOW EXTRAXT JUST THE FUTURE DATA BY USING DF_AND_FUTURE 
# AND QUERYING WHERE DF AND FUTURE "isFuture"....
# WE ARE GOING TO COPY IT AND CALL IT future_w_features. YOU CAN SEE IT GOES ALL THE WAY OUT INTO 2019.

# IT OBVIOUSLY DOESN'T HAVE THE TARGET BECAUSE WE DON'T KNOW THE TRUTH OF THAT...
```


```python
df.index.max()
```




    Timestamp('2018-08-03 00:00:00')




```python
# Create future dataframe
future = pd.date_range('2018-08-03', '2019-08-01', freq='1h')
print(future)
```

    DatetimeIndex(['2018-08-03 00:00:00', '2018-08-03 01:00:00',
                   '2018-08-03 02:00:00', '2018-08-03 03:00:00',
                   '2018-08-03 04:00:00', '2018-08-03 05:00:00',
                   '2018-08-03 06:00:00', '2018-08-03 07:00:00',
                   '2018-08-03 08:00:00', '2018-08-03 09:00:00',
                   ...
                   '2019-07-31 15:00:00', '2019-07-31 16:00:00',
                   '2019-07-31 17:00:00', '2019-07-31 18:00:00',
                   '2019-07-31 19:00:00', '2019-07-31 20:00:00',
                   '2019-07-31 21:00:00', '2019-07-31 22:00:00',
                   '2019-07-31 23:00:00', '2019-08-01 00:00:00'],
                  dtype='datetime64[ns]', length=8713, freq='H')



```python
future_df = pd.DataFrame(index=future)
future_df['isFuture'] = True
df['isFuture'] = False
df_and_future = pd.concat([df, future_df])
df_and_future.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PJME_MW</th>
      <th>hour</th>
      <th>dayofweek</th>
      <th>quarter</th>
      <th>month</th>
      <th>year</th>
      <th>dayofyear</th>
      <th>dayofmonth</th>
      <th>weekofyear</th>
      <th>lag1</th>
      <th>lag2</th>
      <th>lag3</th>
      <th>isFuture</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2002-01-01 01:00:00</th>
      <td>30393.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2002.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2002-01-01 02:00:00</th>
      <td>29265.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2002.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2002-01-01 03:00:00</th>
      <td>28357.0</td>
      <td>3.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2002.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2002-01-01 04:00:00</th>
      <td>27899.0</td>
      <td>4.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2002.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2002-01-01 05:00:00</th>
      <td>28057.0</td>
      <td>5.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2002.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_and_future = create_features(df_and_future)
df_and_future = add_lags(df_and_future)
df_and_future.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PJME_MW</th>
      <th>hour</th>
      <th>dayofweek</th>
      <th>quarter</th>
      <th>month</th>
      <th>year</th>
      <th>dayofyear</th>
      <th>dayofmonth</th>
      <th>weekofyear</th>
      <th>lag1</th>
      <th>lag2</th>
      <th>lag3</th>
      <th>isFuture</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2002-01-01 01:00:00</th>
      <td>30393.0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>2002</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2002-01-01 02:00:00</th>
      <td>29265.0</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>2002</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2002-01-01 03:00:00</th>
      <td>28357.0</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>2002</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2002-01-01 04:00:00</th>
      <td>27899.0</td>
      <td>4</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>2002</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2002-01-01 05:00:00</th>
      <td>28057.0</td>
      <td>5</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>2002</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>




```python
future_w_features = df_and_future.query('isFuture').copy()
future_w_features.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PJME_MW</th>
      <th>hour</th>
      <th>dayofweek</th>
      <th>quarter</th>
      <th>month</th>
      <th>year</th>
      <th>dayofyear</th>
      <th>dayofmonth</th>
      <th>weekofyear</th>
      <th>lag1</th>
      <th>lag2</th>
      <th>lag3</th>
      <th>isFuture</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2019-07-31 20:00:00</th>
      <td>NaN</td>
      <td>20</td>
      <td>2</td>
      <td>3</td>
      <td>7</td>
      <td>2019</td>
      <td>212</td>
      <td>31</td>
      <td>31</td>
      <td>46912.0</td>
      <td>39352.0</td>
      <td>40243.0</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2019-07-31 21:00:00</th>
      <td>NaN</td>
      <td>21</td>
      <td>2</td>
      <td>3</td>
      <td>7</td>
      <td>2019</td>
      <td>212</td>
      <td>31</td>
      <td>31</td>
      <td>45985.0</td>
      <td>38699.0</td>
      <td>39183.0</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2019-07-31 22:00:00</th>
      <td>NaN</td>
      <td>22</td>
      <td>2</td>
      <td>3</td>
      <td>7</td>
      <td>2019</td>
      <td>212</td>
      <td>31</td>
      <td>31</td>
      <td>44094.0</td>
      <td>37346.0</td>
      <td>37759.0</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2019-07-31 23:00:00</th>
      <td>NaN</td>
      <td>23</td>
      <td>2</td>
      <td>3</td>
      <td>7</td>
      <td>2019</td>
      <td>212</td>
      <td>31</td>
      <td>31</td>
      <td>40666.0</td>
      <td>34555.0</td>
      <td>34641.0</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2019-08-01 00:00:00</th>
      <td>NaN</td>
      <td>0</td>
      <td>3</td>
      <td>3</td>
      <td>8</td>
      <td>2019</td>
      <td>213</td>
      <td>1</td>
      <td>31</td>
      <td>37158.0</td>
      <td>31646.0</td>
      <td>31470.0</td>
      <td>True</td>
    </tr>
  </tbody>
</table>
</div>




```python
# NOW LET'S GO AHEAD AND TAKE OUR REGRESSOR AND PREDICT ON THIS FUTURE...
# OF COURSE WE NEED TO PROVIDE THE FEATURES THAT WE TRAINED OUR MODEL ON

future_w_features['pred'] = reg.predict(future_w_features[FEATURES])

future_w_features['pred'].plot(figsize=(10, 5),
                              color = color_pal[4],
                              ms=1,
                              lw=1,
                              title = 'Future Predictions')
```




    <Axes: title={'center': 'Future Predictions'}>




    
![png](output_29_1.png)
    



```python
# NOW,... HOW TO SAVE OUR XGBOOST MODEL FOR LATER?
# LET'S SAY WE DIDN'T WANT TO RETRAIN THIS EVERY TIME WE WANT TO PREDCIT EVERY NEW DAY OR NEW HOUR
# WE CAN ACTUALLY SAVE THIS MODEL VERY EASILY USING SAVE MODEL METHOD ON THIS REGRESSOR
# SO WE ARE GOING TO SAVE THIS MODEL AS MODEL.JSON 

# Save model
reg.save_model('model.json')
```


```python
# WE CAN SHOW THAT WE CAN LOAD THIS BACK IN BY USING XGBOOST REGRESSOR 
# JUST LIKE WE DID BEFORE BY CALLING THIS OUR REG_NEW

reg_new = xgb.XGBRegressor()
reg_new.load_model('model.json')
future_w_features['pred'] = reg_new.predict(future_w_features[FEATURES])
future_w_features['pred'].plot(figsize=(10, 5),
                              color = color_pal[4],
                              ms=1,
                              lw=1,
                              title = 'Future Predictions')
```




    <Axes: title={'center': 'Future Predictions'}>




    
![png](output_31_1.png)
    

